const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Brpl@123',
    database: 'java_quiz'
})

connection.connect((err) => {
    if(err) {
        console.log("This is connection error ->", err);
        throw err;
    }
    console.log("Connected Successfully to MySQL Server...");
})

module.exports = connection;